package org.example;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class MessageServer {
    private String message;
    private String publicKey;
    private String signature;

    public static void main(String[] args) {
        MessageServer server = new MessageServer();
        server.startServer();
    }

    public void startServer() {
        try (ServerSocket serverSocket = new ServerSocket(8080)) {
            System.out.println("Server is listening on port 8080");

            while (true) {
                Socket socket = serverSocket.accept();
                System.out.println("New client connected");

                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

                publicKey = in.readLine();
                message = in.readLine();
                signature = in.readLine();

                socket.close();

                System.out.println("Received message: " + message);
                System.out.println("Received public key: " + publicKey);
                System.out.println("Received signature: " + signature);

                // Allow changing the signature
                Scanner scanner = new Scanner(System.in);
                System.out.println("Enter a new signature (or press Enter to keep the current one):");
                String newSignature = scanner.nextLine();
                if (!newSignature.isEmpty()) {
                    signature = newSignature;
                    System.out.println("Signature updated.");
                }

                // Send data to verifier
                Socket verifierSocket = new Socket("localhost", 8081);
                PrintWriter verifierOut = new PrintWriter(verifierSocket.getOutputStream(), true);

                verifierOut.println(publicKey);
                verifierOut.println(message);
                verifierOut.println(signature);

                verifierSocket.close();
            }

        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}

