package org.example;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

public class MessageVerifier {

    public static void main(String[] args) {
        MessageVerifier verifier = new MessageVerifier();
        verifier.startServer();
    }

    public void startServer() {
        try (ServerSocket serverSocket = new ServerSocket(8081)) {
            System.out.println("Verifier server is listening on port 8081");

            while (true) {
                Socket socket = serverSocket.accept();
                System.out.println("New client connected");

                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                String publicKeyStr = in.readLine();
                String message = in.readLine();
                String signatureStr = in.readLine();

                socket.close();

                System.out.println("Received message: " + message);
                System.out.println("Received public key: " + publicKeyStr);
                System.out.println("Received signature: " + signatureStr);

                boolean isValid = verifySignature(publicKeyStr, message, signatureStr);

                if (isValid) {
                    System.out.println("Signature is valid.");
                } else {
                    System.out.println("Signature is invalid.");
                }
            }

        } catch (IOException | NoSuchAlgorithmException | InvalidKeyException | SignatureException | InvalidKeySpecException ex) {
            ex.printStackTrace();
        }
    }

    public boolean verifySignature(String publicKeyStr, String message, String signatureStr) throws NoSuchAlgorithmException, InvalidKeySpecException, InvalidKeyException, SignatureException {
        byte[] publicKeyBytes = Base64.getDecoder().decode(publicKeyStr);
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(publicKeyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        PublicKey publicKey = keyFactory.generatePublic(keySpec);

        Signature publicSignature = Signature.getInstance("SHA256withRSA");
        publicSignature.initVerify(publicKey);
        publicSignature.update(message.getBytes());

        byte[] signatureBytes = Base64.getDecoder().decode(signatureStr);
        return publicSignature.verify(signatureBytes);
    }
}
