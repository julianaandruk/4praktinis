package org.example;
import java.io.*;
import java.net.Socket;
import java.security.*;
import java.util.Base64;
import java.util.Scanner;

public class MessageSender {
    private KeyPair keyPair;

    public MessageSender() throws NoSuchAlgorithmException {
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
        keyGen.initialize(2048);
        this.keyPair = keyGen.generateKeyPair();
    }

    public static void main(String[] args) {
        try {
            MessageSender sender = new MessageSender();
            Scanner scanner = new Scanner(System.in);
            System.out.println("Enter a message:");
            String message = scanner.nextLine();

            String signature = sender.signMessage(message);

            Socket socket = new Socket("localhost", 8080);
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            out.println(sender.getPublicKey());
            out.println(message);
            out.println(signature);

            socket.close();

            System.out.println("Message, public key, and signature sent to the server.");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String signMessage(String message) throws NoSuchAlgorithmException, InvalidKeyException, SignatureException {
        Signature privateSignature = Signature.getInstance("SHA256withRSA");
        privateSignature.initSign(keyPair.getPrivate());
        privateSignature.update(message.getBytes());

        byte[] signature = privateSignature.sign();
        return Base64.getEncoder().encodeToString(signature);
    }

    public String getPublicKey() {
        return Base64.getEncoder().encodeToString(keyPair.getPublic().getEncoded());
    }
}
